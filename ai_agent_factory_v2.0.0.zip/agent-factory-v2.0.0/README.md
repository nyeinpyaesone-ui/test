# AI Agent Factory v2.0.0

Generated package scaffold.

Run:
docker compose up --build
