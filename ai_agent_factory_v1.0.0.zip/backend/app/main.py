from fastapi import FastAPI
app=FastAPI(title="AI Agent Factory")
@app.get("/health")
def health():
    return {"status":"ok"}
